import express from "express"
const express = require("express"); 
const fs = require("fs");
const router = express.Router();


const loadMovies = () => {
  const data = fs.readFileSync("movies.json");
  return JSON.parse(data);
};


router.get("/top", (req, res) => {
  const limit = parseInt(req.query.limit) || 5;
   const movies = loadMovies()
    .sort((a, b) => b.rating - a.rating)
     .slice(0, limit);
  res.json(movies);
});



router.get("/genre/:genre", (req, res) => {
const genre = req.params.genre.toLowerCase();
  const movies = loadMovies().filter((m) => m.genre.toLowerCase() === genre);
  res.json(movies);
});



router.get("/year", (req, res) => {
 const from = parseInt(req.query.from) || 0;
  const to = parseInt(req.query.to) || new Date().getFullYear();
   const movies = loadMovies().filter((m) => m.year >= from && m.year <= to);
  res.json(movies);
});



router.get("/country/:country", (req, res) => {
  const country = req.params.country.toLowerCase();
  const movies = loadMovies().filter(
    (m) => m.country.toLowerCase() === country
  );
  res.json(movies);
});



router.get("/duration", (req, res) => {
  const time = parseInt(req.query.time);
   const movies = loadMovies().filter((m) => m.duration <= time);
  res.json(movies);
});


router.get("/search", (req, res) => {

  const query = req.query.q.toLowerCase();
  const movies = loadMovies().filter((m) =>
    m.title.toLowerCase().includes(query)
  );
  res.json(movies);
});


router.post("/", (req, res) => {
  const movies = loadMovies();
  const newMovie = req.body;

  if (
    !newMovie.title ||
    !newMovie.year ||
    !newMovie.rating ||
    !newMovie.genre ||
    !newMovie.country ||
    !newMovie.duration
  ) {
    return res.status(400).json({ message: "Barcha maydonlar to‘ldirilishi kerak!" });
  }

  newMovie.id = movies.length + 1;
  movies.push(newMovie);

  fs.writeFileSync("movies.json", JSON.stringify(movies, null, 2));

  res.status(201).json({ message: "Kino qo'shildi!", movie: newMovie });
});

module.exports = router;
