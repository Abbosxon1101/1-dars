import express from "express"
const express = require("express");
const fs = require("fs");
const movieRoutes = require("./routes/movies");

const app = express();
const PORT = 5000;


app.use(express.json());


const loadMovies = () => {
  const data = fs.readFileSync("movies.json");
  return JSON.parse(data);
};


app.get("/", (req, res) => {
  res.send("Movies API ishlayapti!");
});

app.use(express.json());

app.use("/api/movies", movieRoutes);

app.listen(PORT, () => {
  console.log(`Server ${PORT}-portda ishlayapti...`);
});

